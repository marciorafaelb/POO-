#ifndef USUARIO_HPP
#define USUARIO_HPP

#include <string>

class Usuario {
public:
    std::string nome;
    std::string tipo; // "comum" ou "administrador"

    Usuario(std::string nome, std::string tipo) : nome(nome), tipo(tipo) {}
};

#endif // USUARIO_H