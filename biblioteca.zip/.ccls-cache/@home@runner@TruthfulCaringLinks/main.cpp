#include "biblioteca.hpp"
#include <iostream>

int main() {
  Biblioteca biblioteca;

  std::cout << "Bem-vindo ao sistema de biblioteca!" << std::endl;
  std::cout << "Você é um administrador? (1 - Sim, 2 - Não)" << std::endl;

  int escolha;
  std::cin >> escolha;

  switch (escolha) {
  case 1: {
    Usuario usuarioAdministrador("Administrador", "administrador");
    biblioteca.cadastrarUsuario(usuarioAdministrador);

    std::cout << "Opções de administrador:" << std::endl;
    std::cout << "1. Cadastrar livro" << std::endl;
    std::cout << "2. Remover livro" << std::endl;
    std::cout << "3. Mudar disponibilidade de livro" << std::endl;
    std::cout << "4. Listar livros" << std::endl;

    int opcao;
    std::cin >> opcao;

    switch (opcao) {
    case 1: {
      Livro livro("Novo livro", "Autor", 2022);
      biblioteca.cadastrarLivro(livro, usuarioAdministrador);
      break;
    }
    case 2: {
      std::string titulo;
      std::cout << "Digite o título do livro a remover: ";
      std::cin >> titulo;
      biblioteca.removerLivro(titulo);
      break;
    }
    case 3: {
      Livro livro("Livro existente", "Autor", 2020);
      bool disponivel;
      std::cout
          << "Digite a nova disponibilidade do livro (0 - Não, 1 - Sim): ";
      std::cin >> disponivel;
      biblioteca.mudarDisponibilidade(livro, disponivel, usuarioAdministrador);
      break;
    }
    case 4: {
      biblioteca.listarLivros();
      break;
    }
    default:
      std::cout << "Opção inválida!" << std::endl;
    }
    break;
  }
  case 2: {
    Usuario usuarioComum("Usuário comum", "comum");
    biblioteca.cadastrarUsuario(usuarioComum);

    std::cout << "Opções de usuário comum:" << std::endl;
    std::cout << "1. Emprestar livro" << std::endl;
    std::cout << "2. Devolver livro" << std::endl;
    std::cout << "3. Listar livros" << std::endl;

    int opcao;
    std::cin >> opcao;

    switch (opcao) {
    case 1: {
      std::string titulo;
      std::cout << "Digite o título do livro a emprestar: ";
      std::cin >> titulo;
      biblioteca.emprestarLivro(titulo, usuarioComum);
      break;
    }
    case 2: {
      std::string titulo;
      std::cout << "Digite o título do livro a devolver: ";
      std::cin >> titulo;
      biblioteca.devolverLivro(titulo, usuarioComum);
      break;
    }
    case 3: {
      biblioteca.listarLivros();
      break;
    }
    default:
      std::cout << "Opção inválida!" << std::endl;
    }
    break;
  }
  default:
    std::cout << "Opção inválida!" << std::endl;
  }

  return 0;
}