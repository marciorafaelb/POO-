#ifndef BIBLIOTECA_HPP
#define BIBLIOTECA_HPP

#include <vector>
#include <string>

class Usuario {
public:
    std::string nome;
    std::string tipo;

    Usuario(std::string nome, std::string tipo) : nome(nome), tipo(tipo) {}
};

class Livro {
public:
    std::string titulo;
    std::string autor;
    int ano;
    bool disponivel;

    Livro(std::string titulo, std::string autor, int ano) : titulo(titulo), autor(autor), ano(ano), disponivel(true) {}
};

class Biblioteca {
private:
    std::vector<Livro> livros;
    std::vector<Usuario> usuarios;

public:
    void cadastrarUsuario(Usuario usuario);
    void cadastrarLivro(Livro livro, Usuario usuario);
    void emprestarLivro(std::string titulo, Usuario usuario);
    void devolverLivro(std::string titulo, Usuario usuario);
    void mudarDisponibilidade(Livro livro, bool disponivel, Usuario usuario);
    void removerLivro(std::string titulo);
    void listarLivros();
    bool autenticarUsuario(std::string nome, std::string tipo);
};

#endif  // BIBLIOTECA_H