#include "biblioteca.hpp"
#include <iostream>

void Biblioteca::cadastrarUsuario(Usuario usuario) {
  usuarios.push_back(usuario);
  std::cout << "Usuário cadastrado com sucesso!" << std::endl;
}

void Biblioteca::cadastrarLivro(Livro livro, Usuario usuario) {
  if (autenticarUsuario(usuario.nome, usuario.tipo) &&
      usuario.tipo == "administrador") {
    livros.push_back(livro);
    std::cout << "Livro cadastrado com sucesso!" << std::endl;
  } else {
    std::cout << "Você não tem permissão para cadastrar livros!" << std::endl;
  }
}

void Biblioteca::emprestarLivro(std::string titulo, Usuario usuario) {
  for (auto &livro : livros) {
    if (livro.titulo == titulo && livro.disponivel) {
      livro.disponivel = false;
      std::cout << "Livro emprestado com sucesso!" << std::endl;
      return;
    }
  }
  std::cout << "Livro não encontrado ou não disponível!" << std::endl;
}

void Biblioteca::devolverLivro(std::string titulo, Usuario usuario) {
  for (auto &livro : livros) {
    if (livro.titulo == titulo && !livro.disponivel) {
      livro.disponivel = true;
      std::cout << "Livro devolvido com sucesso!" << std::endl;
      return;
    }
  }
  std::cout << "Livro não encontrado ou não emprestado!" << std::endl;
}

void Biblioteca::mudarDisponibilidade(Livro livro, bool disponivel,
                                      Usuario usuario) {
  if (autenticarUsuario(usuario.nome, usuario.tipo) &&
      usuario.tipo == "administrador") {
    for (auto &livro : livros) {
      if (livro.titulo == livro.titulo) {
        livro.disponivel = disponivel;
        std::cout << "Disponibilidade do livro alterada com sucesso!"
                  << std::endl;
        return;
      }
    }
    std::cout << "Livro não encontrado!" << std::endl;
  } else {
    std::cout
        << "Você não tem permissão para alterar a disponibilidade de livros!"
        << std::endl;
  }
}

void Biblioteca::removerLivro(std::string titulo) {
  for (auto it = livros.begin(); it != livros.end(); ++it) {
    if (it->titulo == titulo) {
      livros.erase(it);
      std::cout << "Livro removido com sucesso!" << std::endl;
      return;
    }
  }
  std::cout << "Livro não encontrado!" << std::endl;
}

void Biblioteca::listarLivros() {
  std::cout << "Livros disponíveis:" << std::endl;
  for (const auto &livro : livros) {
    std::cout << "Título: " << livro.titulo << ", Autor: " << livro.autor
              << ", Ano: " << livro.ano
              << ", Disponível: " << (livro.disponivel ? "Sim" : "Não")
              << std::endl;
  }
}

bool Biblioteca::autenticarUsuario(std::string nome, std::string tipo) {
  for (const auto &usuario : usuarios) {
    if (usuario.nome == nome && usuario.tipo == tipo) {
      return true;
    }
  }
  return false;
}